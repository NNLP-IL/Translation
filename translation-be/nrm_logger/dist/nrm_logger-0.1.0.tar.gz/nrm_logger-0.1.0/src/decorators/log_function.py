from src.logger import NRMLogger

logger = NRMLogger()


def log(func):
    def wrapper(*args, **kwargs):
        logger.log(f"Function {func.__name__!r} started")
        result = func(*args, **kwargs)
        logger.log(f"Function {func.__name__!r} ended")
        return result

    return wrapper
